This zip file contains the source files and package.json file used for the Movie Data App.  Let me know if you need all of hte files (the node_modules and public directory); be warned, the total size of all directories is roughly 176mb.  

I can also repackage this app into a single page HTML file using CDN references to both React and Axios.